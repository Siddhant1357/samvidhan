# Samvidhan — India's Constitutional Education Platform

## 🇮🇳 About
A React-based interactive education platform to promote awareness of the Indian Constitution, covering fundamental rights, duties, DPSPs, amendments and more.

## 👥 Roles
| Role | Permissions |
|------|------------|
| **Citizen** | Browse content, take quiz, join discussions |
| **Educator** | Create/manage educational content, sessions |
| **Legal Expert** | Add legal insights, annotate articles |
| **Admin** | Full access: user management, content moderation |

## 📚 Features
- 📜 **Preamble** — Interactive keyword explorer
- ⚖️ **Fundamental Rights** — Deep-dive into all 6 rights (Art. 12–35)
- 🎯 **Fundamental Duties** — Article 51-A with context
- 🗂️ **DPSPs** — Directive Principles with categorization
- 📋 **Amendments** — 106 constitutional amendments
- 🕐 **Timeline** — Historical constitutional journey
- 🧠 **Quiz** — 8-question MCQ with explanations
- 💬 **Discussion Forum** — Community engagement
- 🛡️ **Admin Panel** — User/role management
- 📚 **Educator Hub** — Content creation tools
- ⚖️ **Legal Insights** — Landmark Supreme Court cases

## 🚀 Local Setup
```bash
npm install
npm start
```

## 🌐 Deploy to Vercel
```bash
npm install -g vercel
vercel --prod
```

## 🌐 Deploy to Netlify
```bash
npm run build
# Drop the 'build' folder into Netlify Deploy
```

## Tech Stack
- ⚛️ React 18
- 🎨 Custom CSS (no component library)
- 🖋️ Google Fonts: Playfair Display, Mukta, Noto Serif Devanagari
- 🗂️ React Context API for state management

## 🎨 Design
- **Theme**: Deep navy with saffron, white & green accents (Tricolor)
- **Typography**: Playfair Display (headings) + Mukta (body) + Noto Serif Devanagari (Hindi)
- **Aesthetic**: Refined, editorial, constitutional document-inspired
