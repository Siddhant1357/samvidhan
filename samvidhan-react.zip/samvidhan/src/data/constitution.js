export const constitutionData = {
  overview: {
    adopted: "26 November 1949",
    enforced: "26 January 1950",
    articles: 395,
    schedules: 12,
    parts: 22,
    amendments: 106,
    framers: "Dr. B.R. Ambedkar (Chairman), Drafting Committee",
    preamble: "WE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC and to secure to all its citizens: JUSTICE, social, economic and political; LIBERTY of thought, expression, belief, faith and worship; EQUALITY of status and of opportunity; and to promote among them all FRATERNITY assuring the dignity of the individual and the unity and integrity of the Nation; IN OUR CONSTITUENT ASSEMBLY this twenty-sixth day of November, 1949, do HEREBY ADOPT, ENACT AND GIVE TO OURSELVES THIS CONSTITUTION."
  },
  fundamentalRights: [
    {
      article: "Articles 12–18",
      title: "Right to Equality",
      icon: "⚖️",
      color: "#FF671F",
      description: "Guarantees equality before law, prohibits discrimination on grounds of religion, race, caste, sex or place of birth. Abolishes untouchability.",
      keyPoints: [
        "Equality before law (Art. 14)",
        "Prohibition of discrimination (Art. 15)",
        "Equality of opportunity in public employment (Art. 16)",
        "Abolition of untouchability (Art. 17)",
        "Abolition of titles (Art. 18)"
      ]
    },
    {
      article: "Articles 19–22",
      title: "Right to Freedom",
      icon: "🕊️",
      color: "#C9A84C",
      description: "Protects six freedoms: speech & expression, assembly, association, movement, residence, and profession. Also covers rights in case of arrest.",
      keyPoints: [
        "Freedom of speech & expression (Art. 19(1)(a))",
        "Freedom of peaceful assembly (Art. 19(1)(b))",
        "Freedom to form associations (Art. 19(1)(c))",
        "Freedom of movement (Art. 19(1)(d))",
        "Protection against arbitrary arrest (Art. 22)"
      ]
    },
    {
      article: "Articles 23–24",
      title: "Right Against Exploitation",
      icon: "🚫",
      color: "#046A38",
      description: "Prohibits traffic in human beings, forced labour, and employment of children below 14 years in factories, mines or hazardous occupations.",
      keyPoints: [
        "Prohibition of human trafficking (Art. 23)",
        "Prohibition of forced labour (Art. 23)",
        "Prohibition of child labour (Art. 24)"
      ]
    },
    {
      article: "Articles 25–28",
      title: "Right to Freedom of Religion",
      icon: "🕌",
      color: "#000080",
      description: "Grants freedom of conscience, and free profession, practice and propagation of religion. Ensures religious and linguistic minorities can conserve their culture.",
      keyPoints: [
        "Freedom of conscience (Art. 25)",
        "Freedom to manage religious affairs (Art. 26)",
        "No taxes for religious promotion (Art. 27)",
        "No religious instruction in state institutions (Art. 28)"
      ]
    },
    {
      article: "Articles 29–30",
      title: "Cultural & Educational Rights",
      icon: "🎓",
      color: "#8B0000",
      description: "Protects the rights of minorities to conserve their culture, language and script, and to establish and administer educational institutions.",
      keyPoints: [
        "Protection of interests of minorities (Art. 29)",
        "Right of minorities to establish educational institutions (Art. 30)"
      ]
    },
    {
      article: "Article 32",
      title: "Right to Constitutional Remedies",
      icon: "🏛️",
      color: "#4B0082",
      description: "The 'Heart and Soul' of the Constitution (Dr. Ambedkar). Empowers citizens to move the Supreme Court for enforcement of Fundamental Rights through writs.",
      keyPoints: [
        "Habeas Corpus – produce the body",
        "Mandamus – command to do duty",
        "Prohibition – stop excess of jurisdiction",
        "Quo Warranto – by what authority",
        "Certiorari – quash inferior court order"
      ]
    }
  ],
  dpsp: [
    {
      article: "Art. 38",
      title: "Social Order for Welfare",
      description: "State shall strive to promote welfare of people by securing and protecting a social order of justice."
    },
    {
      article: "Art. 39",
      title: "Equal Pay for Equal Work",
      description: "State to direct policy towards equal pay for equal work for both men and women."
    },
    {
      article: "Art. 44",
      title: "Uniform Civil Code",
      description: "State shall endeavour to secure a Uniform Civil Code for all citizens."
    },
    {
      article: "Art. 45",
      title: "Early Childhood Care",
      description: "Provision for early childhood care and education to all children below age six."
    },
    {
      article: "Art. 48",
      title: "Agriculture & Animal Husbandry",
      description: "State shall endeavour to organize agriculture and animal husbandry on modern scientific lines."
    },
    {
      article: "Art. 51",
      title: "International Peace",
      description: "State shall promote international peace and security, maintain just and honourable relations between nations."
    }
  ],
  fundamentalDuties: [
    { duty: "To abide by the Constitution and respect its ideals, institutions, National Flag and National Anthem." },
    { duty: "To cherish and follow the noble ideals which inspired our national struggle for freedom." },
    { duty: "To uphold and protect the sovereignty, unity and integrity of India." },
    { duty: "To defend the country and render national service when called upon to do so." },
    { duty: "To promote harmony and the spirit of common brotherhood amongst all the people of India." },
    { duty: "To value and preserve the rich heritage of our composite culture." },
    { duty: "To protect and improve the natural environment including forests, lakes, rivers and wildlife." },
    { duty: "To develop the scientific temper, humanism and the spirit of inquiry and reform." },
    { duty: "To safeguard public property and to abjure violence." },
    { duty: "To strive towards excellence in all spheres of individual and collective activity." },
    { duty: "Who is a parent or guardian to provide opportunities for education to his child (6-14 years)." }
  ],
  amendments: [
    { number: "1st (1951)", highlight: true, desc: "Added 9th Schedule; restrictions on free speech" },
    { number: "7th (1956)", highlight: false, desc: "Reorganization of states on linguistic basis" },
    { number: "24th (1971)", highlight: false, desc: "Parliament's power to amend any part of Constitution" },
    { number: "42nd (1976)", highlight: true, desc: "Added 'Socialist', 'Secular', 'Integrity' to Preamble" },
    { number: "44th (1978)", highlight: false, desc: "Restored judicial review; Right to property removed from FR" },
    { number: "52nd (1985)", highlight: false, desc: "Anti-defection law added (10th Schedule)" },
    { number: "61st (1988)", highlight: false, desc: "Voting age lowered from 21 to 18" },
    { number: "73rd (1992)", highlight: true, desc: "Constitutional status to Panchayati Raj institutions" },
    { number: "86th (2002)", highlight: false, desc: "Right to Education added as Fundamental Right" },
    { number: "101st (2016)", highlight: true, desc: "Goods and Services Tax (GST) introduced" },
    { number: "103rd (2019)", highlight: false, desc: "10% reservation for Economically Weaker Sections" },
    { number: "106th (2023)", highlight: true, desc: "33% reservation for women in Parliament and state legislatures" }
  ]
};

export const quizQuestions = [
  {
    q: "Who is known as the 'Father of the Indian Constitution'?",
    options: ["Jawaharlal Nehru", "Mahatma Gandhi", "Dr. B.R. Ambedkar", "Sardar Patel"],
    correct: 2,
    explanation: "Dr. B.R. Ambedkar was the Chairman of the Drafting Committee and is rightly called the Father of the Indian Constitution."
  },
  {
    q: "On which date did the Indian Constitution come into force?",
    options: ["15 August 1947", "26 November 1949", "26 January 1950", "2 October 1950"],
    correct: 2,
    explanation: "The Constitution was adopted on 26 Nov 1949 but came into effect on 26 January 1950, celebrated as Republic Day."
  },
  {
    q: "Which Article of the Constitution is called the 'Heart and Soul' of the Constitution?",
    options: ["Article 14", "Article 19", "Article 21", "Article 32"],
    correct: 3,
    explanation: "Article 32 (Right to Constitutional Remedies) was described by Dr. Ambedkar as the 'Heart and Soul' of the Constitution."
  },
  {
    q: "Which writ is issued to produce a detained person before a court?",
    options: ["Mandamus", "Habeas Corpus", "Certiorari", "Quo Warranto"],
    correct: 1,
    explanation: "Habeas Corpus (meaning 'produce the body') is issued by courts to ensure a person is not unlawfully detained."
  },
  {
    q: "Fundamental Duties were added to the Constitution by which amendment?",
    options: ["24th Amendment", "42nd Amendment", "44th Amendment", "52nd Amendment"],
    correct: 1,
    explanation: "The 42nd Constitutional Amendment (1976) added Fundamental Duties under Article 51-A (Part IV-A)."
  },
  {
    q: "Which schedule of the Constitution deals with Anti-Defection Law?",
    options: ["8th Schedule", "9th Schedule", "10th Schedule", "12th Schedule"],
    correct: 2,
    explanation: "The 10th Schedule, added by the 52nd Amendment (1985), contains provisions related to the Anti-Defection Law."
  },
  {
    q: "The word 'SECULAR' was added to the Preamble by which Constitutional Amendment?",
    options: ["40th Amendment", "42nd Amendment", "44th Amendment", "46th Amendment"],
    correct: 1,
    explanation: "The 42nd Constitutional Amendment (1976) added the words 'Socialist', 'Secular' and 'Integrity' to the Preamble."
  },
  {
    q: "Under which article is the Right to Education guaranteed as a Fundamental Right?",
    options: ["Article 21", "Article 21-A", "Article 23", "Article 29"],
    correct: 1,
    explanation: "Article 21-A, inserted by the 86th Amendment (2002), makes free and compulsory education a fundamental right for children aged 6–14."
  }
];

export const timelineData = [
  { year: "1946", event: "Constituent Assembly formed (Dec 9)" },
  { year: "1947", event: "India gains Independence (Aug 15). Drafting Committee formed (Aug 29)" },
  { year: "1948", event: "Draft Constitution presented by Dr. Ambedkar (Feb 21)" },
  { year: "1949", event: "Constitution adopted by Constituent Assembly (Nov 26)" },
  { year: "1950", event: "Constitution comes into force — Republic Day (Jan 26)" },
  { year: "1951", event: "First Amendment — 9th Schedule created" },
  { year: "1976", event: "42nd Amendment — Preamble updated with 'Socialist', 'Secular'" },
  { year: "1978", event: "44th Amendment — Right to Property removed from FRs" },
  { year: "1992", event: "73rd & 74th Amendments — Panchayati Raj gets constitutional status" },
  { year: "2002", event: "86th Amendment — Right to Education as Fundamental Right" },
  { year: "2016", event: "101st Amendment — GST introduced" },
  { year: "2023", event: "106th Amendment — 33% reservation for women in Parliament" }
];
