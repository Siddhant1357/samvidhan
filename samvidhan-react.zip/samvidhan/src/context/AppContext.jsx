import React, { createContext, useContext, useState } from 'react';

const AppContext = createContext();

export const roles = {
  citizen: { label: 'Citizen', color: '#046A38', icon: '🏛️', canEdit: false, canManage: false, canLegal: false },
  educator: { label: 'Educator', color: '#FF671F', icon: '📚', canEdit: true, canManage: false, canLegal: false },
  legal_expert: { label: 'Legal Expert', color: '#C9A84C', icon: '⚖️', canEdit: true, canManage: false, canLegal: true },
  admin: { label: 'Admin', color: '#000080', icon: '🛡️', canEdit: true, canManage: true, canLegal: true },
};

export function AppProvider({ children }) {
  const [currentRole, setCurrentRole] = useState('citizen');
  const [activeSection, setActiveSection] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [quizScore, setQuizScore] = useState(null);
  const [notifications] = useState([
    { id: 1, text: 'New article on Article 21 published', time: '2h ago', unread: true },
    { id: 2, text: 'Quiz: Fundamental Rights – try now!', time: '5h ago', unread: true },
    { id: 3, text: 'Legal Expert added commentary on DPSPs', time: '1d ago', unread: false },
  ]);

  return (
    <AppContext.Provider value={{
      currentRole, setCurrentRole,
      activeSection, setActiveSection,
      searchQuery, setSearchQuery,
      quizScore, setQuizScore,
      notifications,
      roleData: roles[currentRole],
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
