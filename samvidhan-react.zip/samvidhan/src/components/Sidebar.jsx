import React, { useState } from 'react';
import { useApp, roles } from '../context/AppContext';
import './Sidebar.css';

const navItems = [
  { id: 'dashboard', icon: '⊞', label: 'Dashboard', group: 'main' },
  { id: 'preamble', icon: '📜', label: 'Preamble', group: 'learn' },
  { id: 'rights', icon: '⚖️', label: 'Fundamental Rights', group: 'learn' },
  { id: 'duties', icon: '🎯', label: 'Fundamental Duties', group: 'learn' },
  { id: 'dpsp', icon: '🗂️', label: 'Directive Principles', group: 'learn' },
  { id: 'amendments', icon: '📋', label: 'Amendments', group: 'learn' },
  { id: 'timeline', icon: '🕐', label: 'Timeline', group: 'learn' },
  { id: 'quiz', icon: '🧠', label: 'Quiz', badge: 'New', group: 'engage' },
  { id: 'discuss', icon: '💬', label: 'Discussions', group: 'engage' },
  { id: 'admin', icon: '🛡️', label: 'Admin Panel', group: 'admin', roleReq: 'admin' },
  { id: 'educator', icon: '📚', label: 'Educator Hub', group: 'admin', roleReq: ['educator', 'admin'] },
  { id: 'legal', icon: '🏛️', label: 'Legal Insights', group: 'admin', roleReq: ['legal_expert', 'admin'] },
];

export default function Sidebar({ mobile, onClose }) {
  const { currentRole, setCurrentRole, activeSection, setActiveSection } = useApp();
  const [chakraHover, setChakraHover] = useState(false);

  const visibleItems = navItems.filter(item => {
    if (!item.roleReq) return true;
    if (Array.isArray(item.roleReq)) return item.roleReq.includes(currentRole);
    return item.roleReq === currentRole;
  });

  const groups = ['main', 'learn', 'engage', 'admin'];
  const groupLabels = { main: null, learn: 'Constitutional Learning', engage: 'Interactive', admin: 'Management' };

  return (
    <aside className={`sidebar ${mobile ? 'sidebar-mobile' : ''}`}>
      {mobile && <button className="sidebar-close" onClick={onClose}>✕</button>}

      {/* Logo */}
      <div className="sidebar-logo">
        <div
          className={`chakra-wrap ${chakraHover ? 'spin-fast' : ''}`}
          onMouseEnter={() => setChakraHover(true)}
          onMouseLeave={() => setChakraHover(false)}
        >
          <div className="ashoka-chakra">
            {[...Array(24)].map((_, i) => (
              <div key={i} className="spoke" style={{ transform: `rotate(${i * 15}deg)` }} />
            ))}
            <div className="chakra-center" />
          </div>
        </div>
        <div>
          <span className="logo-dev">संविधान</span>
          <span className="logo-en">SAMVIDHAN</span>
          <span className="logo-tag">India's Constitution Platform</span>
        </div>
      </div>

      <div className="tricolor-strip" style={{ margin: '0 20px' }} />

      {/* Role Selector */}
      <div className="role-panel">
        <p className="role-panel-label">Your Role</p>
        <div className="role-grid">
          {Object.entries(roles).map(([key, r]) => (
            <button
              key={key}
              onClick={() => setCurrentRole(key)}
              className={`role-btn ${currentRole === key ? 'active' : ''}`}
              style={currentRole === key ? { borderColor: r.color, color: r.color } : {}}
            >
              <span>{r.icon}</span>
              <span>{r.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Navigation */}
      <nav className="sidebar-nav">
        {groups.map(group => {
          const items = visibleItems.filter(i => i.group === group);
          if (!items.length) return null;
          return (
            <div key={group}>
              {groupLabels[group] && (
                <p className="nav-group-label">{groupLabels[group]}</p>
              )}
              {items.map(item => (
                <button
                  key={item.id}
                  className={`nav-item ${activeSection === item.id ? 'active' : ''}`}
                  onClick={() => { setActiveSection(item.id); if (mobile) onClose(); }}
                >
                  <span className="nav-icon">{item.icon}</span>
                  <span className="nav-label">{item.label}</span>
                  {item.badge && <span className="nav-badge">{item.badge}</span>}
                </button>
              ))}
            </div>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="tricolor-strip" />
        <p className="footer-text">© 2024 Samvidhan Platform</p>
      </div>
    </aside>
  );
}
