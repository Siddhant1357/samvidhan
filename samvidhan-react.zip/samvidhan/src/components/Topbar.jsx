import React, { useState } from 'react';
import { useApp, roles } from '../context/AppContext';
import './Topbar.css';

export default function Topbar({ onMenuClick }) {
  const { currentRole, activeSection, searchQuery, setSearchQuery, notifications } = useApp();
  const role = roles[currentRole];
  const unread = notifications.filter(n => n.unread).length;
  const [showNotif, setShowNotif] = useState(false);

  const sectionLabels = {
    dashboard: 'Dashboard', preamble: 'The Preamble', rights: 'Fundamental Rights',
    duties: 'Fundamental Duties', dpsp: 'Directive Principles of State Policy',
    amendments: 'Constitutional Amendments', timeline: 'Historical Timeline',
    quiz: 'Interactive Quiz', discuss: 'Discussion Forum',
    admin: 'Admin Panel', educator: 'Educator Hub', legal: 'Legal Insights'
  };

  return (
    <header className="topbar">
      <div className="topbar-left">
        <button className="menu-btn" onClick={onMenuClick}>☰</button>
        <div>
          <h2 className="topbar-title">{sectionLabels[activeSection] || 'Dashboard'}</h2>
          <p className="topbar-breadcrumb">Samvidhan / <span className="gold">{sectionLabels[activeSection]}</span></p>
        </div>
      </div>

      <div className="topbar-right">
        <div className="search-wrap">
          <span className="search-icon">🔍</span>
          <input
            className="search-input"
            placeholder="Search constitution..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="notif-wrap">
          <button className="icon-btn" onClick={() => setShowNotif(!showNotif)}>
            🔔
            {unread > 0 && <span className="notif-dot">{unread}</span>}
          </button>
          {showNotif && (
            <div className="notif-dropdown">
              <p className="notif-header">Notifications</p>
              {notifications.map(n => (
                <div key={n.id} className={`notif-item ${n.unread ? 'unread' : ''}`}>
                  <p className="notif-text">{n.text}</p>
                  <p className="notif-time">{n.time}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="user-chip">
          <div className="user-avatar" style={{ background: `linear-gradient(135deg, ${role.color}, ${role.color}99)` }}>
            {role.icon}
          </div>
          <div className="user-info">
            <span className="user-role">{role.label}</span>
            <span className="user-name">Demo User</span>
          </div>
        </div>
      </div>
    </header>
  );
}
