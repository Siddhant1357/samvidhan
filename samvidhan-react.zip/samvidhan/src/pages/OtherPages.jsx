import React, { useState } from 'react';
import { constitutionData, timelineData } from '../data/constitution';
import { useApp } from '../context/AppContext';

/* ======= FUNDAMENTAL DUTIES ======= */
export function FundamentalDuties() {
  return (
    <div style={{ padding: '32px 36px' }}>
      <h2 className="section-title fade-up">Fundamental Duties</h2>
      <p className="section-subtitle fade-up">Article 51-A — Part IV-A, added by the 42nd Amendment (1976). Inspired by the USSR Constitution.</p>

      <div className="grid-2 fade-up-1" style={{ marginBottom: 28 }}>
        <div className="card" style={{ padding: 24, background: 'rgba(255,103,31,0.08)', borderColor: 'rgba(255,103,31,0.2)' }}>
          <h4 style={{ fontFamily: 'Playfair Display', fontSize: 18, marginBottom: 8, color: 'var(--saffron)' }}>📋 Background</h4>
          <p style={{ fontSize: 13, lineHeight: 1.8, color: 'rgba(253,246,227,0.8)' }}>
            Fundamental Duties were not in the original Constitution. They were added by the 42nd Amendment (1976)
            based on the recommendations of the Swaran Singh Committee. Originally there were 10 duties; 
            the 86th Amendment (2002) added the 11th duty related to education.
          </p>
        </div>
        <div className="card" style={{ padding: 24, background: 'rgba(4,106,56,0.08)', borderColor: 'rgba(4,106,56,0.2)' }}>
          <h4 style={{ fontFamily: 'Playfair Display', fontSize: 18, marginBottom: 8, color: 'var(--green)' }}>⚠️ Nature</h4>
          <p style={{ fontSize: 13, lineHeight: 1.8, color: 'rgba(253,246,227,0.8)' }}>
            Unlike Fundamental Rights, Fundamental Duties are <strong>non-justiciable</strong> — they cannot be 
            enforced by a court. However, Parliament can enact laws to enforce them. 
            They serve as a moral obligation on citizens.
          </p>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {constitutionData.fundamentalDuties.map((d, i) => (
          <div key={i} className="card fade-up" style={{
            padding: '16px 20px',
            display: 'flex',
            gap: 16,
            alignItems: 'flex-start',
            animationDelay: `${i * 0.05}s`,
          }}>
            <div style={{
              width: 38, height: 38, borderRadius: 8,
              background: 'rgba(201,168,76,0.15)',
              color: 'var(--gold)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Playfair Display', fontWeight: 700, fontSize: 16,
              flexShrink: 0,
            }}>{i + 1}</div>
            <div>
              <p style={{ fontSize: 10, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 4 }}>Duty {i + 1}</p>
              <p style={{ fontSize: 14, lineHeight: 1.7, color: 'rgba(253,246,227,0.9)' }}>{d.duty}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ======= DPSP ======= */
export function DPSP() {
  return (
    <div style={{ padding: '32px 36px' }}>
      <h2 className="section-title fade-up">Directive Principles of State Policy</h2>
      <p className="section-subtitle fade-up">Part IV (Articles 36–51) — inspired by the Irish Constitution. Non-justiciable but fundamental to governance.</p>

      <div className="card fade-up-1" style={{ padding: 22, marginBottom: 28, background: 'rgba(0,0,128,0.1)', borderColor: 'rgba(0,0,128,0.3)' }}>
        <p style={{ fontSize: 14, lineHeight: 1.8, color: 'rgba(253,246,227,0.85)' }}>
          <strong style={{ color: 'var(--gold)' }}>Key distinction:</strong> While Fundamental Rights are justiciable (courts can enforce them),
          DPSPs are non-justiciable — they cannot be enforced in a court of law. However, in <em>Minerva Mills v. Union of India (1980)</em>,
          the Supreme Court held that both Fundamental Rights and DPSPs together constitute the 'core' of the Constitution and must be in harmony.
        </p>
      </div>

      <div className="grid-3 fade-up-2">
        {constitutionData.dpsp.map((d, i) => (
          <div key={i} className="card" style={{ padding: 20, borderTop: '3px solid var(--gold)' }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, color: 'var(--gold)', marginBottom: 8 }}>{d.article}</p>
            <h4 style={{ fontFamily: 'Playfair Display', fontSize: 16, marginBottom: 8 }}>{d.title}</h4>
            <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.7 }}>{d.description}</p>
          </div>
        ))}
      </div>

      <div className="card fade-up-3" style={{ padding: 24, marginTop: 28, borderColor: 'rgba(255,103,31,0.3)' }}>
        <h4 style={{ fontFamily: 'Playfair Display', fontSize: 18, marginBottom: 12, color: 'var(--saffron)' }}>Categories of DPSPs</h4>
        <div className="grid-3">
          {[
            { label: 'Socialistic', color: '#046A38', desc: 'Promote welfare of people — Art. 38, 39, 41, 42, 43, 43A, 47' },
            { label: 'Gandhian', color: '#FF671F', desc: 'Based on Gandhian philosophy — Art. 40, 43, 43B, 46, 47, 48' },
            { label: 'Liberal-Intellectual', color: '#000080', desc: 'Based on liberal ideology — Art. 44, 45, 48, 48A, 49, 50, 51' },
          ].map(c => (
            <div key={c.label} style={{ padding: 16, background: `${c.color}11`, borderRadius: 10, border: `1px solid ${c.color}33` }}>
              <p style={{ color: c.color, fontWeight: 700, marginBottom: 6 }}>{c.label}</p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{c.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ======= AMENDMENTS ======= */
export function Amendments() {
  const [filter, setFilter] = useState('all');
  const amends = filter === 'key' ? constitutionData.amendments.filter(a => a.highlight) : constitutionData.amendments;

  return (
    <div style={{ padding: '32px 36px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }} className="fade-up">
        <div>
          <h2 className="section-title">Constitutional Amendments</h2>
          <p className="section-subtitle" style={{ marginBottom: 0 }}>India has seen 106 amendments since 1950, shaping its democracy.</p>
        </div>
        <div className="tab-group">
          <button className={`tab-btn ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>All</button>
          <button className={`tab-btn ${filter === 'key' ? 'active' : ''}`} onClick={() => setFilter('key')}>Key Ones</button>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {amends.map((a, i) => (
          <div key={i} className="card fade-up" style={{
            padding: '16px 22px',
            display: 'flex',
            gap: 18,
            alignItems: 'center',
            borderLeft: a.highlight ? '3px solid var(--saffron)' : '3px solid transparent',
            animationDelay: `${i * 0.04}s`
          }}>
            <div style={{ width: 130, flexShrink: 0 }}>
              <p style={{ fontFamily: 'Playfair Display', fontWeight: 700, fontSize: 14, color: a.highlight ? 'var(--saffron)' : 'var(--gold)' }}>{a.number}</p>
            </div>
            <p style={{ fontSize: 14, color: 'rgba(253,246,227,0.85)', flex: 1 }}>{a.desc}</p>
            {a.highlight && <span className="badge" style={{ background: 'rgba(255,103,31,0.2)', color: 'var(--saffron)', flexShrink: 0 }}>Landmark</span>}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ======= TIMELINE ======= */
export function Timeline() {
  return (
    <div style={{ padding: '32px 36px' }}>
      <h2 className="section-title fade-up">Constitutional Timeline</h2>
      <p className="section-subtitle fade-up">Key milestones in India's constitutional journey</p>

      <div className="timeline-wrap fade-up-1">
        {timelineData.map((t, i) => (
          <div key={i} className="tl-item">
            <div className="tl-year-col">
              <p className="tl-year">{t.year}</p>
            </div>
            <div className="tl-line-col">
              <div className="tl-dot" />
              {i < timelineData.length - 1 && <div className="tl-line" />}
            </div>
            <div className="tl-content card">
              <p style={{ fontSize: 14, lineHeight: 1.6 }}>{t.event}</p>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        .timeline-wrap { display: flex; flex-direction: column; gap: 0; max-width: 700px; margin: 0 auto; }
        .tl-item { display: grid; grid-template-columns: 80px 30px 1fr; gap: 0; align-items: flex-start; }
        .tl-year-col { display: flex; justify-content: flex-end; padding-right: 12px; padding-top: 12px; }
        .tl-year { font-family: 'Playfair Display', serif; font-size: 18px; font-weight: 700; color: var(--gold); }
        .tl-line-col { display: flex; flex-direction: column; align-items: center; }
        .tl-dot { width: 14px; height: 14px; border-radius: 50%; background: var(--saffron); border: 2px solid var(--navy); box-shadow: 0 0 0 3px rgba(255,103,31,0.3); margin-top: 14px; flex-shrink: 0; }
        .tl-line { flex: 1; width: 2px; background: linear-gradient(to bottom, var(--saffron), transparent); min-height: 40px; }
        .tl-content { padding: 12px 16px; margin: 8px 0 8px 12px; font-size: 14px; }
      `}</style>
    </div>
  );
}

/* ======= DISCUSSIONS ======= */
const MOCK_POSTS = [
  { id: 1, user: 'Citizen_A', role: 'Citizen', avatar: '👤', time: '2h ago', title: 'Is Article 21 the most powerful fundamental right?', body: 'The Supreme Court has consistently expanded the scope of Article 21 to include the right to livelihood, privacy, health, education...', replies: 12, likes: 34 },
  { id: 2, user: 'Adv_Meera', role: 'Legal Expert', avatar: '⚖️', time: '5h ago', title: 'Understanding the Basic Structure Doctrine', body: 'After Kesavananda Bharati (1973), Parliament cannot amend the Constitution in a way that destroys its basic structure...', replies: 8, likes: 56 },
  { id: 3, user: 'Prof_Kumar', role: 'Educator', avatar: '📚', time: '1d ago', title: 'DPSPs vs Fundamental Rights — A historical debate', body: 'When the Constitution was framed, there was significant debate about which should take precedence...', replies: 19, likes: 78 },
];

export function Discussions() {
  const { currentRole } = useApp();
  const [posts, setPosts] = useState(MOCK_POSTS);
  const [newPost, setNewPost] = useState({ title: '', body: '' });
  const [showForm, setShowForm] = useState(false);

  const handlePost = () => {
    if (!newPost.title || !newPost.body) return;
    setPosts([{
      id: Date.now(), user: `${currentRole}_user`, role: currentRole,
      avatar: '✏️', time: 'Just now', title: newPost.title, body: newPost.body, replies: 0, likes: 0
    }, ...posts]);
    setNewPost({ title: '', body: '' });
    setShowForm(false);
  };

  return (
    <div style={{ padding: '32px 36px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }} className="fade-up">
        <div>
          <h2 className="section-title">Discussion Forum</h2>
          <p className="section-subtitle" style={{ marginBottom: 0 }}>Engage with the constitutional community</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>✍️ New Post</button>
      </div>

      {showForm && (
        <div className="card fade-up" style={{ padding: 24, marginBottom: 20, borderColor: 'rgba(255,103,31,0.3)' }}>
          <h4 style={{ fontFamily: 'Playfair Display', marginBottom: 14, fontSize: 18 }}>Create Post</h4>
          <input
            style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px', color: 'var(--cream)', fontFamily: 'Mukta', fontSize: 14, marginBottom: 10, outline: 'none' }}
            placeholder="Post title..."
            value={newPost.title}
            onChange={e => setNewPost({ ...newPost, title: e.target.value })}
          />
          <textarea
            style={{ width: '100%', background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)', borderRadius: 8, padding: '10px 14px', color: 'var(--cream)', fontFamily: 'Mukta', fontSize: 14, outline: 'none', resize: 'vertical', minHeight: 100 }}
            placeholder="Share your thoughts on the Constitution..."
            value={newPost.body}
            onChange={e => setNewPost({ ...newPost, body: e.target.value })}
          />
          <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
            <button className="btn btn-primary" onClick={handlePost}>Post</button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {posts.map((p, i) => (
          <div key={p.id} className="card fade-up" style={{ padding: 24, animationDelay: `${i * 0.08}s` }}>
            <div style={{ display: 'flex', gap: 14, marginBottom: 12, alignItems: 'flex-start' }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(201,168,76,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>{p.avatar}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 4 }}>
                  <span style={{ fontWeight: 700, fontSize: 14 }}>{p.user}</span>
                  <span className="badge" style={{ background: 'rgba(201,168,76,0.15)', color: 'var(--gold)', fontSize: 10 }}>{p.role}</span>
                  <span style={{ color: 'var(--text-muted)', fontSize: 11 }}>{p.time}</span>
                </div>
                <h4 style={{ fontFamily: 'Playfair Display', fontSize: 17 }}>{p.title}</h4>
              </div>
            </div>
            <p style={{ fontSize: 13, color: 'rgba(253,246,227,0.75)', lineHeight: 1.7, marginBottom: 14 }}>{p.body}</p>
            <div style={{ display: 'flex', gap: 16, fontSize: 12, color: 'var(--text-muted)' }}>
              <span>💬 {p.replies} replies</span>
              <span>❤️ {p.likes} likes</span>
              <button style={{ background: 'none', border: 'none', color: 'var(--gold)', cursor: 'pointer', fontSize: 12, fontFamily: 'Mukta' }}>Reply</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ======= ADMIN ======= */
export function AdminPanel() {
  const users = [
    { name: 'Dr. Priya Sharma', role: 'Legal Expert', status: 'Active', posts: 24 },
    { name: 'Prof. Arun Kumar', role: 'Educator', status: 'Active', posts: 47 },
    { name: 'Rahul Singh', role: 'Citizen', status: 'Active', posts: 12 },
    { name: 'Kavita Nair', role: 'Educator', status: 'Pending', posts: 0 },
    { name: 'Amit Patel', role: 'Legal Expert', status: 'Active', posts: 31 },
  ];
  const roleColors = { 'Legal Expert': '#C9A84C', Educator: '#FF671F', Citizen: '#046A38' };

  return (
    <div style={{ padding: '32px 36px' }}>
      <h2 className="section-title fade-up">Admin Panel</h2>
      <p className="section-subtitle fade-up">Manage users, roles, and platform content</p>

      <div className="grid-4 fade-up-1" style={{ marginBottom: 28 }}>
        {[
          { label: 'Total Users', val: '1,247', icon: '👥', c: '#FF671F' },
          { label: 'Active Today', val: '89', icon: '🟢', c: '#046A38' },
          { label: 'Posts Published', val: '342', icon: '📝', c: '#C9A84C' },
          { label: 'Pending Review', val: '7', icon: '⏳', c: '#000080' },
        ].map(s => (
          <div key={s.label} className="card" style={{ padding: 18, display: 'flex', gap: 12, alignItems: 'center' }}>
            <div style={{ width: 42, height: 42, borderRadius: 10, background: `${s.c}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>{s.icon}</div>
            <div>
              <p style={{ fontFamily: 'Playfair Display', fontSize: 24, fontWeight: 700, color: s.c, lineHeight: 1 }}>{s.val}</p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="card fade-up-2" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '16px 22px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h4 style={{ fontFamily: 'Playfair Display', fontSize: 18 }}>User Management</h4>
          <button className="btn btn-outline" style={{ fontSize: 12, padding: '6px 14px' }}>+ Invite User</button>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'rgba(255,255,255,0.03)' }}>
              {['Name', 'Role', 'Status', 'Posts', 'Actions'].map(h => (
                <th key={h} style={{ padding: '12px 20px', textAlign: 'left', fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: 'var(--text-muted)', fontFamily: 'Mukta' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={i} style={{ borderTop: '1px solid var(--border)' }}>
                <td style={{ padding: '14px 20px', fontSize: 14, fontWeight: 600 }}>{u.name}</td>
                <td style={{ padding: '14px 20px' }}>
                  <span className="badge" style={{ background: `${roleColors[u.role] || '#666'}22`, color: roleColors[u.role] || '#666' }}>{u.role}</span>
                </td>
                <td style={{ padding: '14px 20px' }}>
                  <span style={{ fontSize: 12, color: u.status === 'Active' ? '#046A38' : '#C9A84C' }}>● {u.status}</span>
                </td>
                <td style={{ padding: '14px 20px', fontSize: 14, color: 'var(--text-muted)' }}>{u.posts}</td>
                <td style={{ padding: '14px 20px' }}>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-ghost" style={{ fontSize: 11, padding: '4px 10px' }}>Edit</button>
                    <button className="btn btn-ghost" style={{ fontSize: 11, padding: '4px 10px', color: '#8B0000', borderColor: '#8B000033' }}>Remove</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ======= EDUCATOR HUB ======= */
export function EducatorHub() {
  const resources = [
    { title: 'Introduction to the Indian Constitution', type: 'Article', reads: '2.3K', status: 'Published' },
    { title: 'Fundamental Rights — Video Lecture Series', type: 'Video', reads: '1.8K', status: 'Published' },
    { title: 'Quiz: Constitutional Amendments', type: 'Quiz', reads: '956', status: 'Draft' },
    { title: 'Directive Principles Explained', type: 'Article', reads: '1.1K', status: 'Published' },
  ];

  return (
    <div style={{ padding: '32px 36px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24 }} className="fade-up">
        <div>
          <h2 className="section-title">Educator Hub</h2>
          <p className="section-subtitle" style={{ marginBottom: 0 }}>Create and manage educational constitutional content</p>
        </div>
        <button className="btn btn-primary">+ Create Content</button>
      </div>

      <div className="grid-3 fade-up-1" style={{ marginBottom: 28 }}>
        {[
          { label: 'My Articles', val: '14', icon: '📄' },
          { label: 'Total Reads', val: '6.2K', icon: '👁️' },
          { label: 'Sessions', val: '8', icon: '🎓' },
        ].map(s => (
          <div key={s.label} className="card" style={{ padding: 22, textAlign: 'center' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>{s.icon}</div>
            <p style={{ fontFamily: 'Playfair Display', fontSize: 32, color: 'var(--gold)', fontWeight: 700 }}>{s.val}</p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div className="card fade-up-2" style={{ overflow: 'hidden' }}>
        <div style={{ padding: '16px 22px', borderBottom: '1px solid var(--border)' }}>
          <h4 style={{ fontFamily: 'Playfair Display', fontSize: 18 }}>My Resources</h4>
        </div>
        {resources.map((r, i) => (
          <div key={i} style={{ padding: '16px 22px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 14, alignItems: 'center' }}>
            <div style={{ width: 40, height: 40, borderRadius: 8, background: 'rgba(255,103,31,0.15)', color: 'var(--saffron)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
              {r.type === 'Article' ? '📄' : r.type === 'Video' ? '🎬' : '❓'}
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontWeight: 600, fontSize: 14 }}>{r.title}</p>
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>{r.type} · {r.reads} reads</p>
            </div>
            <span className="badge" style={{ background: r.status === 'Published' ? 'rgba(4,106,56,0.2)' : 'rgba(201,168,76,0.15)', color: r.status === 'Published' ? '#046A38' : '#C9A84C' }}>{r.status}</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="btn btn-ghost" style={{ fontSize: 11, padding: '5px 12px' }}>Edit</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ======= LEGAL INSIGHTS ======= */
export function LegalInsights() {
  const cases = [
    { name: 'Kesavananda Bharati v. State of Kerala', year: 1973, significance: 'Established the Basic Structure Doctrine — Parliament cannot amend the Constitution to destroy its basic structure.', area: 'Constitutional Amendment' },
    { name: 'Maneka Gandhi v. Union of India', year: 1978, significance: 'Expanded Article 21 to include the right to live with dignity; introduced the principle of due process.', area: 'Fundamental Rights' },
    { name: 'Indira Sawhney v. Union of India', year: 1992, significance: 'Upheld 27% OBC reservations; capped total reservations at 50%; excluded creamy layer.', area: 'Equality & Reservations' },
    { name: 'S.R. Bommai v. Union of India', year: 1994, significance: 'Curtailed arbitrary imposition of President\'s Rule under Article 356; federalism is a basic feature.', area: 'Federalism' },
    { name: 'K.S. Puttaswamy v. Union of India', year: 2017, significance: 'Unanimously declared Privacy as a Fundamental Right under Article 21 of the Constitution.', area: 'Fundamental Rights' },
  ];
  const areaColors = { 'Constitutional Amendment': '#FF671F', 'Fundamental Rights': '#C9A84C', 'Equality & Reservations': '#046A38', 'Federalism': '#000080' };

  return (
    <div style={{ padding: '32px 36px' }}>
      <h2 className="section-title fade-up">Legal Insights</h2>
      <p className="section-subtitle fade-up">Landmark Supreme Court cases shaping constitutional interpretation</p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {cases.map((c, i) => (
          <div key={i} className="card fade-up" style={{
            padding: 24,
            borderLeft: `3px solid ${areaColors[c.area] || 'var(--gold)'}`,
            animationDelay: `${i * 0.1}s`
          }}>
            <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', marginBottom: 10 }}>
              <div style={{ flex: 1 }}>
                <h4 style={{ fontFamily: 'Playfair Display', fontSize: 17, marginBottom: 6 }}>{c.name}</h4>
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                  <span className="badge" style={{ background: `${areaColors[c.area]}22`, color: areaColors[c.area] }}>{c.area}</span>
                  <span className="badge" style={{ background: 'rgba(255,255,255,0.07)', color: 'var(--text-muted)' }}>AIR {c.year} SC</span>
                </div>
              </div>
            </div>
            <p style={{ fontSize: 14, lineHeight: 1.7, color: 'rgba(253,246,227,0.85)' }}>{c.significance}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
