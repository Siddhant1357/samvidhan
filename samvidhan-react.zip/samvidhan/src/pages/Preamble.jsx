import React, { useState } from 'react';
import { constitutionData } from '../data/constitution';
import './Preamble.css';

const keywords = {
  'SOVEREIGN': { color: '#FF671F', def: 'India is supreme in internal matters and free from external control.' },
  'SOCIALIST': { color: '#C9A84C', def: 'Added in 1976; aims to eliminate inequality of income and status.' },
  'SECULAR': { color: '#046A38', def: 'Added in 1976; the state treats all religions equally with no official state religion.' },
  'DEMOCRATIC': { color: '#000080', def: 'Government is elected by the people through universal adult franchise.' },
  'REPUBLIC': { color: '#8B0000', def: 'The head of state (President) is elected, not hereditary.' },
  'JUSTICE': { color: '#4B0082', def: 'Social, economic and political justice for all citizens.' },
  'LIBERTY': { color: '#FF671F', def: 'Liberty of thought, expression, belief, faith and worship.' },
  'EQUALITY': { color: '#C9A84C', def: 'Equality of status and opportunity for all citizens.' },
  'FRATERNITY': { color: '#046A38', def: 'Brotherhood among citizens, ensuring dignity of individuals and national unity.' },
};

export default function Preamble() {
  const [hoveredWord, setHoveredWord] = useState(null);
  const { preamble } = constitutionData.overview;

  const renderPreamble = () => {
    let text = preamble;
    const parts = [];
    let lastIndex = 0;

    // Find keywords in order they appear
    const keywordPositions = [];
    Object.keys(keywords).forEach(kw => {
      let idx = text.indexOf(kw, 0);
      while (idx !== -1) {
        keywordPositions.push({ kw, idx, end: idx + kw.length });
        idx = text.indexOf(kw, idx + 1);
      }
    });
    keywordPositions.sort((a, b) => a.idx - b.idx);

    keywordPositions.forEach(({ kw, idx, end }) => {
      if (idx >= lastIndex) {
        if (idx > lastIndex) parts.push(<span key={`t-${idx}`}>{text.slice(lastIndex, idx)}</span>);
        parts.push(
          <span
            key={`k-${idx}`}
            className="preamble-keyword"
            style={{ color: keywords[kw].color, borderBottomColor: keywords[kw].color }}
            onMouseEnter={() => setHoveredWord(kw)}
            onMouseLeave={() => setHoveredWord(null)}
          >
            {kw}
          </span>
        );
        lastIndex = end;
      }
    });
    if (lastIndex < text.length) parts.push(<span key="t-end">{text.slice(lastIndex)}</span>);
    return parts;
  };

  return (
    <div className="preamble-page">
      <div className="preamble-header fade-up">
        <div>
          <h2 className="section-title">The Preamble</h2>
          <p className="section-subtitle">The philosophical foundation of the Indian Constitution — adopted 26 November 1949</p>
        </div>
        <div className="tricolor-strip" style={{ width: 120 }} />
      </div>

      <div className="preamble-main">
        {/* Preamble Document */}
        <div className="preamble-doc card fade-up-1">
          <div className="doc-header">
            <div className="ashoka-small">
              {[...Array(24)].map((_, i) => (
                <div key={i} style={{
                  position: 'absolute',
                  width: '1px', height: '50%',
                  background: 'var(--gold)',
                  top: 0, left: '50%',
                  transformOrigin: 'bottom center',
                  transform: `rotate(${i * 15}deg)`,
                  opacity: 0.7
                }} />
              ))}
              <div style={{ position: 'absolute', width: 10, height: 10, background: 'var(--gold)', borderRadius: '50%', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }} />
            </div>
            <div>
              <p className="doc-header-dev">प्रस्तावना</p>
              <p className="doc-header-en">PREAMBLE TO THE CONSTITUTION OF INDIA</p>
            </div>
          </div>
          <div className="doc-tricolor">
            <div style={{ background: 'var(--saffron)', height: 4, flex: 1 }} />
            <div style={{ background: 'white', height: 4, flex: 1 }} />
            <div style={{ background: 'var(--green)', height: 4, flex: 1 }} />
          </div>
          <div className="doc-body">
            <p className="preamble-text">{renderPreamble()}</p>
          </div>
          <div className="doc-footer">
            <p>IN OUR CONSTITUENT ASSEMBLY</p>
            <p className="doc-date">26th November, 1949</p>
          </div>
        </div>

        {/* Keywords sidebar */}
        <div className="keywords-side fade-up-2">
          <h4 className="keywords-title">Key Concepts</h4>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 14 }}>Hover over highlighted words in the Preamble to learn more</p>
          <div className="keywords-list">
            {Object.entries(keywords).map(([kw, { color, def }]) => (
              <div
                key={kw}
                className={`keyword-item card ${hoveredWord === kw ? 'active' : ''}`}
                style={hoveredWord === kw ? { borderColor: color, background: `${color}11` } : {}}
              >
                <div className="kw-header">
                  <span className="kw-dot" style={{ background: color }} />
                  <span className="kw-word" style={{ color }}>{kw}</span>
                </div>
                <p className="kw-def">{def}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Amendment note */}
      <div className="card amend-note fade-up-3">
        <span className="amend-icon">ℹ️</span>
        <div>
          <p className="amend-title">42nd Constitutional Amendment (1976)</p>
          <p className="amend-text">The words <strong>"SOCIALIST"</strong>, <strong>"SECULAR"</strong>, and <strong>"INTEGRITY"</strong> were added to the Preamble by the 42nd Constitutional Amendment during the Emergency period under PM Indira Gandhi. The Supreme Court in <em>Kesavananda Bharati v. State of Kerala (1973)</em> held that the Preamble is a part of the Constitution but cannot alone be amended to destroy its basic structure.</p>
        </div>
      </div>
    </div>
  );
}
