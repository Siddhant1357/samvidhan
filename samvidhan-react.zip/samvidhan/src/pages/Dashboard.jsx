import React from 'react';
import { useApp, roles } from '../context/AppContext';
import { constitutionData } from '../data/constitution';
import './Dashboard.css';

const stats = [
  { label: 'Articles', value: '395', icon: '📄', color: '#FF671F' },
  { label: 'Schedules', value: '12', icon: '📋', color: '#C9A84C' },
  { label: 'Parts', value: '22', icon: '🗂️', color: '#046A38' },
  { label: 'Amendments', value: '106', icon: '✏️', color: '#000080' },
];

const quickLinks = [
  { id: 'preamble', icon: '📜', title: 'Preamble', desc: 'Foundation of the Constitution', color: '#FF671F' },
  { id: 'rights', icon: '⚖️', title: 'Fundamental Rights', desc: 'Articles 12–35', color: '#C9A84C' },
  { id: 'duties', icon: '🎯', title: 'Duties', desc: 'Article 51-A', color: '#046A38' },
  { id: 'dpsp', icon: '🗂️', title: 'DPSPs', desc: 'Part IV directive principles', color: '#000080' },
  { id: 'quiz', icon: '🧠', title: 'Take Quiz', desc: 'Test your knowledge', color: '#8B0000' },
  { id: 'timeline', icon: '🕐', title: 'Timeline', desc: 'Constitutional history', color: '#4B0082' },
];

export default function Dashboard() {
  const { currentRole, setActiveSection } = useApp();
  const role = roles[currentRole];

  return (
    <div className="dashboard">
      {/* Welcome Hero */}
      <div className="dash-hero fade-up">
        <div className="dash-hero-bg" />
        <div className="dash-hero-content">
          <div className="hero-badge">
            <span className="tricolor-dot saffron-dot" />
            <span className="tricolor-dot white-dot" />
            <span className="tricolor-dot green-dot" />
            <span>Republic of India — 26 January 1950</span>
          </div>
          <h1 className="hero-title">
            <span className="devanagari">संविधान</span>
            <span>of India</span>
          </h1>
          <p className="hero-sub">
            Explore the supreme law of India — its principles, rights, duties, and democratic framework.
            You are viewing as <strong style={{ color: role.color }}>{role.icon} {role.label}</strong>
          </p>
          <div className="hero-actions">
            <button className="btn btn-primary" onClick={() => setActiveSection('preamble')}>
              📜 Read Preamble
            </button>
            <button className="btn btn-outline" onClick={() => setActiveSection('quiz')}>
              🧠 Take Quiz
            </button>
          </div>
        </div>
        <div className="hero-quote">
          <div className="chakra-large">
            {[...Array(24)].map((_, i) => (
              <div key={i} className="spoke-lg" style={{ transform: `rotate(${i * 15}deg)` }} />
            ))}
            <div className="chakra-center-lg" />
          </div>
          <p className="hero-preamble-excerpt">
            "We, the People of India, having solemnly resolved to constitute India into a Sovereign Socialist Secular Democratic Republic..."
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4 fade-up-1" style={{ marginBottom: 28 }}>
        {stats.map(s => (
          <div key={s.label} className="stat-card card">
            <div className="stat-icon" style={{ background: `${s.color}22`, color: s.color }}>{s.icon}</div>
            <div>
              <p className="stat-value" style={{ color: s.color }}>{s.value}</p>
              <p className="stat-label">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="dash-grid">
        {/* Quick Links */}
        <div className="fade-up-2">
          <h3 className="section-title" style={{ fontSize: 20, marginBottom: 16 }}>Explore Constitution</h3>
          <div className="quick-grid">
            {quickLinks.map(l => (
              <button key={l.id} className="quick-card card" onClick={() => setActiveSection(l.id)}>
                <span className="quick-icon" style={{ background: `${l.color}22`, color: l.color }}>{l.icon}</span>
                <div>
                  <p className="quick-title">{l.title}</p>
                  <p className="quick-desc">{l.desc}</p>
                </div>
                <span className="quick-arrow">→</span>
              </button>
            ))}
          </div>
        </div>

        {/* Right Panel */}
        <div className="dash-right fade-up-3">
          {/* Key Facts */}
          <div className="card info-card" style={{ marginBottom: 20 }}>
            <h4 className="info-card-title">📊 Key Constitutional Facts</h4>
            <div className="facts-list">
              <div className="fact-row">
                <span className="fact-key">Adopted</span>
                <span className="fact-val gold">{constitutionData.overview.adopted}</span>
              </div>
              <div className="fact-row">
                <span className="fact-key">Enforced</span>
                <span className="fact-val gold">{constitutionData.overview.enforced}</span>
              </div>
              <div className="fact-row">
                <span className="fact-key">Principal Author</span>
                <span className="fact-val" style={{ fontSize: 12 }}>Dr. B.R. Ambedkar</span>
              </div>
              <div className="fact-row">
                <span className="fact-key">Languages</span>
                <span className="fact-val">Hindi & English</span>
              </div>
              <div className="fact-row">
                <span className="fact-key">Total Amendments</span>
                <span className="fact-val" style={{ color: 'var(--saffron)' }}>106</span>
              </div>
            </div>
          </div>

          {/* Preamble keywords */}
          <div className="card info-card">
            <h4 className="info-card-title">🔑 Preamble Keywords</h4>
            <div className="keywords">
              {['Sovereign', 'Socialist', 'Secular', 'Democratic', 'Republic', 'Justice', 'Liberty', 'Equality', 'Fraternity'].map(w => (
                <span key={w} className="keyword-chip">{w}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Role Features */}
      {(role.canEdit || role.canManage || role.canLegal) && (
        <div className="role-features fade-up" style={{ marginTop: 28 }}>
          <h3 className="section-title" style={{ fontSize: 18, marginBottom: 14 }}>
            {role.icon} {role.label} Features
          </h3>
          <div className="grid-3">
            {role.canEdit && (
              <div className="card feature-card">
                <span className="feature-icon">✏️</span>
                <h4>Content Management</h4>
                <p>Create, edit, and publish constitutional content and educational materials.</p>
                <button className="btn btn-ghost" style={{ marginTop: 12, fontSize: 12 }} onClick={() => setActiveSection('educator')}>
                  Open Educator Hub →
                </button>
              </div>
            )}
            {role.canLegal && (
              <div className="card feature-card">
                <span className="feature-icon">⚖️</span>
                <h4>Legal Annotations</h4>
                <p>Add legal commentary, case references, and expert insights to articles.</p>
                <button className="btn btn-ghost" style={{ marginTop: 12, fontSize: 12 }} onClick={() => setActiveSection('legal')}>
                  Open Legal Insights →
                </button>
              </div>
            )}
            {role.canManage && (
              <div className="card feature-card">
                <span className="feature-icon">🛡️</span>
                <h4>Platform Administration</h4>
                <p>Manage users, roles, content moderation and platform settings.</p>
                <button className="btn btn-ghost" style={{ marginTop: 12, fontSize: 12 }} onClick={() => setActiveSection('admin')}>
                  Open Admin Panel →
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
