import React, { useState } from 'react';
import { constitutionData } from '../data/constitution';
import './Rights.css';

export default function FundamentalRights() {
  const [selected, setSelected] = useState(0);
  const rights = constitutionData.fundamentalRights;
  const right = rights[selected];

  return (
    <div className="rights-page">
      <div className="fade-up">
        <h2 className="section-title">Fundamental Rights</h2>
        <p className="section-subtitle">Part III of the Constitution — Articles 12–35 — the cornerstone of individual liberty in India</p>
      </div>

      <div className="rights-layout">
        {/* Left: Card list */}
        <div className="rights-list fade-up-1">
          {rights.map((r, i) => (
            <button
              key={i}
              className={`right-card card ${selected === i ? 'active' : ''}`}
              onClick={() => setSelected(i)}
              style={selected === i ? { borderColor: r.color, background: `${r.color}11` } : {}}
            >
              <div className="rc-icon" style={{ background: `${r.color}22`, color: r.color }}>{r.icon}</div>
              <div className="rc-info">
                <p className="rc-article" style={{ color: r.color }}>{r.article}</p>
                <p className="rc-title">{r.title}</p>
              </div>
              <span className="rc-arrow" style={selected === i ? { color: r.color } : {}}>→</span>
            </button>
          ))}
        </div>

        {/* Right: Detail panel */}
        <div className="right-detail card fade-up-2" key={selected}>
          <div className="rd-header" style={{ background: `${right.color}18`, borderBottom: `1px solid ${right.color}33` }}>
            <div className="rd-icon-lg" style={{ background: `${right.color}30`, color: right.color }}>{right.icon}</div>
            <div>
              <p className="rd-article" style={{ color: right.color }}>{right.article}</p>
              <h3 className="rd-title">{right.title}</h3>
            </div>
          </div>

          <div className="rd-body">
            <p className="rd-desc">{right.description}</p>

            <div className="rd-points-header">
              <span className="rd-points-line" style={{ background: right.color }} />
              <p className="rd-points-title" style={{ color: right.color }}>Key Provisions</p>
            </div>
            <div className="rd-points">
              {right.keyPoints.map((p, i) => (
                <div key={i} className="rd-point">
                  <span className="rd-point-dot" style={{ background: right.color }} />
                  <p>{p}</p>
                </div>
              ))}
            </div>

            {right.article.includes('32') && (
              <div className="writs-section">
                <h4 className="writs-title">The Five Constitutional Writs</h4>
                <div className="writs-grid">
                  {[
                    { name: 'Habeas Corpus', latin: 'Have the body', desc: 'Against illegal detention' },
                    { name: 'Mandamus', latin: 'We command', desc: 'Direct public authority to perform duty' },
                    { name: 'Certiorari', latin: 'To be certified', desc: 'Quash orders of inferior courts' },
                    { name: 'Prohibition', latin: 'To forbid', desc: 'Prevent courts from exceeding jurisdiction' },
                    { name: 'Quo Warranto', latin: 'By what authority', desc: 'Challenge a public office claim' },
                  ].map(w => (
                    <div key={w.name} className="writ-card card">
                      <p className="writ-name">{w.name}</p>
                      <p className="writ-latin"><em>{w.latin}</em></p>
                      <p className="writ-desc">{w.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom: All rights at a glance */}
      <div className="rights-glance fade-up-3">
        <h3 className="section-title" style={{ fontSize: 20, marginBottom: 16 }}>Rights at a Glance</h3>
        <div className="glance-grid">
          {rights.map((r, i) => (
            <div
              key={i}
              className="glance-card card"
              onClick={() => setSelected(i)}
              style={{ cursor: 'pointer', borderTop: `3px solid ${r.color}` }}
            >
              <span style={{ fontSize: 24 }}>{r.icon}</span>
              <p className="glance-title">{r.title}</p>
              <p className="glance-art" style={{ color: r.color }}>{r.article}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
