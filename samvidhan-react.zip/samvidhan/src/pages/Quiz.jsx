import React, { useState } from 'react';
import { quizQuestions } from '../data/constitution';
import './Quiz.css';

export default function Quiz() {
  const [phase, setPhase] = useState('start'); // start | quiz | result
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [showExp, setShowExp] = useState(false);

  const q = quizQuestions[current];
  const score = answers.filter((a, i) => a === quizQuestions[i].correct).length;

  const handleStart = () => { setPhase('quiz'); setCurrent(0); setAnswers([]); setSelected(null); setShowExp(false); };

  const handleSelect = (idx) => {
    if (selected !== null) return;
    setSelected(idx);
    setShowExp(true);
  };

  const handleNext = () => {
    const newAnswers = [...answers, selected];
    setAnswers(newAnswers);
    if (current + 1 >= quizQuestions.length) {
      setPhase('result');
    } else {
      setCurrent(current + 1);
      setSelected(null);
      setShowExp(false);
    }
  };

  const getGrade = (s, total) => {
    const pct = (s / total) * 100;
    if (pct >= 87.5) return { label: 'Excellent!', color: '#046A38', icon: '🏆', desc: 'You have mastered the Indian Constitution!' };
    if (pct >= 62.5) return { label: 'Good', color: '#C9A84C', icon: '🌟', desc: 'Solid knowledge. Review a few more articles.' };
    if (pct >= 37.5) return { label: 'Fair', color: '#FF671F', icon: '📚', desc: 'Keep studying. Try reading the highlighted sections.' };
    return { label: 'Needs Work', color: '#8B0000', icon: '💪', desc: 'Start with Fundamental Rights and the Preamble.' };
  };

  if (phase === 'start') return (
    <div className="quiz-page">
      <div className="quiz-start fade-up">
        <div className="quiz-start-icon">🧠</div>
        <h2 className="section-title" style={{ textAlign: 'center' }}>Constitutional Knowledge Quiz</h2>
        <p className="quiz-start-desc">Test your understanding of the Indian Constitution through {quizQuestions.length} carefully crafted questions covering Fundamental Rights, Amendments, historical facts, and more.</p>
        <div className="quiz-meta-grid">
          <div className="quiz-meta-card card">
            <span>❓</span>
            <p className="qm-val">{quizQuestions.length}</p>
            <p className="qm-label">Questions</p>
          </div>
          <div className="quiz-meta-card card">
            <span>⏱️</span>
            <p className="qm-val">~8</p>
            <p className="qm-label">Minutes</p>
          </div>
          <div className="quiz-meta-card card">
            <span>📊</span>
            <p className="qm-val">MCQ</p>
            <p className="qm-label">Format</p>
          </div>
          <div className="quiz-meta-card card">
            <span>🎯</span>
            <p className="qm-val">1 pt</p>
            <p className="qm-label">Per Question</p>
          </div>
        </div>
        <button className="btn btn-primary" style={{ fontSize: 16, padding: '14px 36px' }} onClick={handleStart}>
          Start Quiz →
        </button>
      </div>
    </div>
  );

  if (phase === 'result') {
    const grade = getGrade(score, quizQuestions.length);
    return (
      <div className="quiz-page">
        <div className="quiz-result fade-up">
          <div className="result-icon" style={{ background: `${grade.color}22` }}>{grade.icon}</div>
          <h2 className="result-grade" style={{ color: grade.color }}>{grade.label}</h2>
          <div className="result-score">
            <span className="score-num" style={{ color: grade.color }}>{score}</span>
            <span className="score-sep">/</span>
            <span className="score-total">{quizQuestions.length}</span>
          </div>
          <p className="result-desc">{grade.desc}</p>

          {/* Bar chart */}
          <div className="result-bar-wrap card">
            <div className="result-bar-track">
              <div className="result-bar-fill" style={{ width: `${(score / quizQuestions.length) * 100}%`, background: grade.color }} />
            </div>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 6 }}>
              {Math.round((score / quizQuestions.length) * 100)}% score
            </p>
          </div>

          {/* Review answers */}
          <div className="review-section">
            <h4 style={{ marginBottom: 14, fontFamily: 'Playfair Display', fontSize: 18 }}>Answer Review</h4>
            {quizQuestions.map((qq, i) => (
              <div key={i} className={`review-item card ${answers[i] === qq.correct ? 'correct' : 'incorrect'}`}>
                <div className="review-header">
                  <span className="review-num">Q{i + 1}</span>
                  <p className="review-q">{qq.q}</p>
                  <span className="review-result">{answers[i] === qq.correct ? '✅' : '❌'}</span>
                </div>
                <p className="review-answer">
                  Your answer: <strong style={{ color: answers[i] === qq.correct ? '#046A38' : '#8B0000' }}>{qq.options[answers[i]]}</strong>
                </p>
                {answers[i] !== qq.correct && (
                  <p className="review-correct">Correct: <strong style={{ color: '#046A38' }}>{qq.options[qq.correct]}</strong></p>
                )}
                <p className="review-exp">{qq.explanation}</p>
              </div>
            ))}
          </div>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 24 }}>
            <button className="btn btn-primary" onClick={handleStart}>Try Again</button>
            <button className="btn btn-outline" onClick={() => setPhase('start')}>Back to Start</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="quiz-page">
      <div className="quiz-main fade-up">
        {/* Progress */}
        <div className="quiz-progress-wrap">
          <div className="quiz-progress-bar">
            <div className="quiz-progress-fill" style={{ width: `${(current / quizQuestions.length) * 100}%` }} />
          </div>
          <p className="quiz-counter">Question {current + 1} of {quizQuestions.length}</p>
        </div>

        <div className="quiz-card card">
          <div className="quiz-qnum">
            <span style={{ background: 'rgba(255,103,31,0.2)', color: 'var(--saffron)' }} className="badge">Question {current + 1}</span>
          </div>
          <h3 className="quiz-question">{q.q}</h3>

          <div className="quiz-options">
            {q.options.map((opt, i) => {
              let cls = 'quiz-option';
              if (selected !== null) {
                if (i === q.correct) cls += ' option-correct';
                else if (i === selected) cls += ' option-wrong';
                else cls += ' option-dimmed';
              }
              return (
                <button key={i} className={cls} onClick={() => handleSelect(i)}>
                  <span className="opt-letter">{String.fromCharCode(65 + i)}</span>
                  <span className="opt-text">{opt}</span>
                  {selected !== null && i === q.correct && <span className="opt-check">✓</span>}
                  {selected !== null && i === selected && i !== q.correct && <span className="opt-x">✗</span>}
                </button>
              );
            })}
          </div>

          {showExp && (
            <div className="quiz-explanation" style={{ borderColor: selected === q.correct ? '#046A38' : '#FF671F' }}>
              <span style={{ fontSize: 18 }}>{selected === q.correct ? '✅' : '❌'}</span>
              <p>{q.explanation}</p>
            </div>
          )}

          {selected !== null && (
            <button className="btn btn-primary" style={{ marginTop: 20, width: '100%' }} onClick={handleNext}>
              {current + 1 === quizQuestions.length ? 'See Results' : 'Next Question →'}
            </button>
          )}
        </div>

        {/* Dots */}
        <div className="quiz-dots">
          {quizQuestions.map((_, i) => (
            <div key={i} className={`quiz-dot ${i < current ? 'done' : i === current ? 'current' : ''}`} />
          ))}
        </div>
      </div>
    </div>
  );
}
